#!/bin/bash

 #+++++++++++++++++++++++++++++++++++++++++++++++
 # Function: download Sentinel-1 orbit data
 # Input: 
	# sensing date as array, you can inout an array or read it form some script like grep_S1_dates.sh
	# Mission Type Selected: S1A, S1B or both
	# (Orbit Type Selected:POEORB or RESORB)
 # Output:
	# orbit data you need
	# sh_downloading_S1_opod.log
 # Author: Zelong Guo, @GFZ, Potadam
 # Email: zelong.guo@gfz-potsdam.de
 # First Version: 15/11/2020,18:19
 #+++++ Program Function Explaination +++++#
 #----- Program Grammar Explaination  -----#
 #+++++++++++++++++++++++++++++++++++++++++++++++

#+++++++++++++++++++++++++++++++++++++ update log ++++++++++++++++++++++++++++++++++++++++++++
# 20.11.2020, 13:19 @ GFZ: debuged that the sensing day is the 1st and last day of every month
# 29.11.2020, 13:36 @ GFZ: the function of reading array form grep_S1_dates.log
#+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

#/////////////////////////////////////////////////////////////////////
# NEXT UPDATE: the function of select the Orbit Type: POEORB or RESORB
#/////////////////////////////////////////////////////////////////////

#-----------------------------------------------------------------------------------------------------
# 运行目录：任意目录下即可，（最好是在OPOD目录下），脚本默认读取grep_S1_dates.log中的文件，需要与其在同一目录下
# 输入参数：
#		1. sensing_date数组，可以在grep_S1_dates.log中读入，这样的情况下sensing_date就无需设置(默认如此);否则可以手动输入
#		2. 命令行输入：要下载的轨道数据属于S1A，S1B还是两者都要
#-----------------------------------------------------------------------------------------------------

#-------------------------------------------------------------------------------
# if的多个条件判断都需要用[]连接
# -lt等只能用与判断integer类型，==既可用于判断integer也能用于判断string，注意区别
#------------------------------------------------------------------------------- 
if [ "$#" -lt "1" ] || [ "$1" == "-help" ] || [ "$1" == "--help"  ]; then
	printf "\n"
	echo "#+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++"
	echo "Function: download Sentinel-1 orbit data"
	echo "Input: "
	echo "		sensing date as array, you can inout an array or read it form some script like grep_S1_dates.sh "
	echo "		Mission Type Selected: S1A, S1B or both"
	# Orbit Type Selected:POEORB or RESORB
	echo "Output:"
	echo " 		orbit data you need"
	echo "		sh_downloading_S1_opod.log"
	echo "Author: Zelong Guo, @GFZ, Potadam"
	echo "Email: zelong.guo@gfz-potsdam.de"
	echo "First Version: 15/11/2020,18:19"
	echo "#+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++"
	printf "\n"
	printf "Please input SAR mission NO.: (S1A, S1B or BOTH,[s1a, s1b or both]): "
	printf "\n"
	exit
fi

#++++++++++++++++++++++++++ creat the sh_downloading_S1_opod.log+++++++++++++++++++++++++++#
[ -e "sh_downloading_S1_opod.log" ] && rm sh_downloading_S1_opod.log
echo "Download Log of Orb_S1_Download.sh " > sh_downloading_S1_opod.log
printf "\n" >> sh_downloading_S1_opod.log
echo "++++++++++++++++++++++++++++++++++++++++++" >> sh_downloading_S1_opod.log
echo "Function: download Sentinel-1 orbit data" >> sh_downloading_S1_opod.log
echo "Author: Zelong Guo, @gfz, Potadam" >> sh_downloading_S1_opod.log
echo "Email: zelong.guo@gfz-potsdam.de" >> sh_downloading_S1_opod.log
echo "First version: 15/11/2020" >> sh_downloading_S1_opod.log
echo "++++++++++++++++++++++++++++++++++++++++++" >> sh_downloading_S1_opod.log
printf "\n\n" >> sh_downloading_S1_opod.log

#+++++++++++++++++++ count the download times +++++++++++++++++++++++++++#
do_flag=0
undo_flag=0

mission_type=$1
S1_dates=$2

#------------------------------------------------------------------------------#
# sensing_date 可以手动输入，也可以与grep_S1_dates.sh结合使用，grep_S1_dates.sh
# 会生成grep_S1_dates.log,在此，我们以参数$2传入，在这个文件中读取里面的日期数据.
#------------------------------------------------------------------------------#
#sensing_date=(20200131 20200201) #手动输入 or 从文件中读取：
sensing_date_read=$(cat $2 | awk '{print $0}')
index=0;
for sensing_date_read_index in $sensing_date_read
do
	sensing_date[$index]=$sensing_date_read_index
	let index+=1
done
#-----------------------------------------------------------------------#
# 格式一定要准确，YYYYMMDD格式, 否则会出错
# 下次更新需注明文件运行的目录，（比如像gammit在工程目录下一样）
#----------------------------------------------------------------------#


#++++++++++++++++++ extract the POEORB orbit file lists from asf +++++++++++++++++++++#
echo "Now connecting to the website of ASF..."
ASF="https://s1qc.asf.alaska.edu/aux_poeorb/"
file_list=$(curl -s -u zelong:GuoZeLong0928 $ASF) 
[ "$?" -ne "0" ] && echo "Error! Please check!" && exit
echo "Connected!"
#echo "$file_list"

#+++++++++++++++++++++++ Confirm: S1A, S1B or BOTH ++++++++++++++++++++++++++++++#
if [ "$mission_type" == "S1A" ] || [ "$mission_type" == "s1a" ]; then
	file_list_mission=$(echo "$file_list" | grep "href=\"S1A" | awk '{print $2}' | sed 's/^.*="//g' | sed 's/">.*$//g')
elif [ "$mission_type" == "S1B" ] || [ "$mission_type" == "s1b" ]; then
	file_list_mission=$(echo "$file_list" | grep "href=\"S1B" | awk '{print $2}' | sed 's/^.*="//g' | sed 's/">.*$//g')
elif [ "$mission_type" == "BOTH" ] || [ "$mission_type" == "both" ]; then
	file_list_mission=$(echo "$file_list" | grep "href=\"S1" | awk '{print $2}' | sed 's/^.*="//g' | sed 's/">.*$//g')
else
	printf "\n\n++++++++++++++++++++++++++++++++++++++++++++++++++++++++\n"
	printf "$0: \tThe argument you inputed is INCORRECT!\nPlease input the mission type: S1A, S1B or BOTH (s1a, s1b or both)!\n\n\n"
	exit
fi

#echo "$file_list_mission"
[ "x$file_list_mission" = "x" ] && echo "$0: Not found files!"
#--------------------------------------------------------#
# 1. 判断符号[],里面所有的组件都必须用空格键来分隔
# 2. 所有的变量和常数都要用双引号""括起来。
#--------------------------------------------------------#


for ((i=0;i<${#sensing_date[*]};i++))
do
	let validity_start=$(date -d "${sensing_date[$i]} -1 days" "+%Y%m%d")
	let validity_stop=$(date -d "${sensing_date[$i]} +1 days" "+%Y%m%d")
#	let validity_start=${sensing_date[$i]}-1
#	let validity_stop=${sensing_date[$i]}+1


#++++++++++++++++++++++++ Matching the files that you need to download ++++++++++++++++++++++++++++++#

file_list_need=$(echo "$file_list_mission" | grep ${validity_start}'.*'${validity_stop} )
#echo "$file_list_need" 
#------------------------------------------------------------------------------------------------------------#
# 1.（1）如果是单行结果赋值给变量：
#上面grep一行也可以写成：grep "${validity_start"'.*'"${validity_stop"}, 两者的区别就在于变量有没有被""包括起来，
#其实，对于单行元素，输出结果 echo $validity_start = echo "$validity_start"，也就是""返回变量的‘值’，而echo 
# '$validity_start'返回的是 $validity_start,返回的仅仅是‘字符串’而已！
# 1.（2）如果是多行元素赋值给变量：也即如果$validity_start有多行
# echo $validity_start != echo "$validity_start"!!!!!!!!!!!!!这是因为echo $validity_start 返回的结果就是1行，而
# echo "$validity_start"返回的是多行，也即按照原格式输出!!!!!!!注意此处，建议使用双引号!!!!!!!!!!!!!!!!
#
# 2.grep的通常用法就是grep ‘’，所以上面的正则表达式.*要用‘’括起来，也可以看出，grep不仅可以精确查找含某个字符串的
#行，还可以查找含两个乃至多个字符串的行（利用正则表达式的任意字节.与重复字节*）！正则表达式还要继续学习.
#
# 3.上面其实也等于grep $validity_start | grep $validity_stop, 也就是连用两个grep,所以最准确的写法应该是
#grep $validity_start'........'$validity_stop (指明两个变量之间存在8个任意字节)
#
# 4.在bash shell中，很多符号意义是不同的：比如，*在Linux代表通配符;在正则表达式代表任意字符;而awk中则有其自己的语
#法. 比如单引号的使用：awk 'NR=='$i' {print $0}' url_1.log awk引用外部变量i必须用单引号双引号什么的括起来，还比较
#复杂没弄清楚，或者也可以使用-v来声明外部变量（下面有用），这一点与上面我们提到的是不同的，因此可以理解为awk自有语法.
#------------------------------------------------------------------------------------------------------------#
#echo "$?"

#:<<!
	if [ "$mission_type" == "S1A" ] || [ "$mission_type" == "s1a" ] || [ "$mission_type" == "S1B" ] || [ "$mission_type" == "s1b" ]; then
	
		if [ ! -n "$file_list_need" ]; then 
			printf "The %s orbit is not being downloaded, the sensing date is %i\n" $mission_type ${sensing_date[$i]} >> sh_downloading_S1_opod.log
			let undo_flag+=1
		else
			let do_flag+=1
			wget --no-check-certificate --user=zelong --password=GuoZeLong0928 -c $ASF$file_list_need
			printf "\n\n+++++++++++++++++++++++++++++++++++++++++++++++++++++\n"
			printf '\tDownload sucessfully %i files\n' $do_flag
			printf '\tPlease see the sh_downloading_S1_opod.log.'
			printf '\n\n'
			#----------------------------------------------------
			#echo 不支持\n,\t等字符，printf更为强大
			# if []内的内容同判断符号[]的写法
			#---------------------------------------------------#
		fi

	else
		line_num=$(echo "$file_list_need" | wc -l)
		word_num=$(echo "$file_list_need" | wc -w)
		#------------------------------------------#	
		# 想要向读取文件一样来读取变量就先echo一下！！
		# 文件可以用cat全取出来，变量要用echo全读出来
		#------------------------------------------#
		echo "**************************************"
		[ "$line_num" == "1"  ] && [ "$word_num" == "0"  ] && let line_num=0 
		#-----------------------------------------------------------------------------------------#	
		# 判断$file_list_need有几行（分别对应于下方的0,1或2行），可问题是就算$file_list_need是0行，
		# 其$line_num值仍然为1,因此又引入了变量来统计单词数目，如果单词数目也为0的话，就证明没有
		# 记录，从而令line_num为0.	**********不知道该行能否继续优化*********
		#-----------------------------------------------------------------------------------------#

		if [ "$line_num" == "0"  ]; then
			printf "The %s of s1a and s1b orbits is not being downloaded, the sensing date is %i\n" $mission_type ${sensing_date[$i]} >> sh_downloading_S1_opod.log
			let undo_flag+=2
		elif [ "$line_num" == "1" ]; then
			printf "The one of (s1b)  %s of orbits is not being downloaded, the sensing date is %i\n" $mission_type ${sensing_date[$i]} >> sh_downloading_S1_opod.log
			let do_flag+=1
			let undo_flag+=1
			wget --no-check-certificate --user=zelong --password=GuoZeLong0928 -c $ASF$file_list_need
			printf "\n\n+++++++++++++++++++++++++++++++++++++++++++++++++++++\n"
			printf '\tDownload Situation:\n\t%i files successed, %i fialed\n' $do_flag $undo_flag
			printf '\tPlease see the sh_downloading_S1_opod.log.'
			printf '\n\n'
		elif [ "$line_num" == "2" ]; then
			let do_flag+=2
			echo "$file_list_need" | awk -v ASF=$ASF '{tep=ASF$0; print tep}'  > file_list_need.log
			#--------------------------------------------------------------------------#
			#注意echo内的变量需要用""包起来，因为file_list_need含有多行!!!!!!
			# 注意awk引用外部变量的时候可以用-v指明，用单双引号也可以，但是感觉比较繁琐
			#--------------------------------------------------------------------------#
			wget --no-check-certificate --user=zelong --password=GuoZeLong0928 -c -i file_list_need.log
			printf "\n\n+++++++++++++++++++++++++++++++++++++++++++++++++++++\n"
			printf '\tDownload Situation:\n\t%i files successed, %i fialed\n' $do_flag $undo_flag
			printf '\tPlease see the sh_downloading_S1_opod.log.'
			printf '\n\n'
			rm file_list_need.log
		else
			printf "\n\n+++++++++++++++++++++++++++++++++++++++++++++++++++++\n"
			printf "$0: ERROR with the file list needed!\n"
			echo "$file_list_need"
			echo "$line_num"
		fi	
		
	fi

#!
done


#++++++++++++++++++++++++++++++++++++++++++ Write to the log +++++++++++++++++++++++++++++++++++++++++++++++++++#

if [ "$mission_type" == "S1A" ] || [ "$mission_type" == "s1a" ] || [ "$mission_type" == "S1B" ] || [ "$mission_type" == "s1b" ]; then
	let total_flag=do_flag+undo_flag
	printf "\n\n" >> sh_downloading_S1_opod.log
	printf "Total %i files\n" $total_flag >> sh_downloading_S1_opod.log
	printf "Successfully downloaded %i files, failed %i files \n" $do_flag $undo_flag >> sh_downloading_S1_opod.log
	date "+%Y-%m-%d %H:%M:%S" >> sh_downloading_S1_opod.log
else
	let total_flag=do_flag+undo_flag
	printf "\n\n" >> sh_downloading_S1_opod.log
	printf "Total %i files\n" $total_flag >> sh_downloading_S1_opod.log
	printf "Successfully downloaded %i files, failed %i files \n" $do_flag $undo_flag >> sh_downloading_S1_opod.log
	date "+%Y-%m-%d %H:%M:%S" >> sh_downloading_S1_opod.log
fi



#!/bin/bash

#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
# pre-checking the files needed (data, oppd and dem).
# This script need to be used in sh_gamma.sh, cannot run independently
# This script need to call for sh_grep_S1_dates.sh, to link the SAR data you need from ori_SARdir to procdir
# Zelong Guo @GFZ
# zelong@gfz-potsdam.de
# First Version: 10/12/2020
# last edited: 31/12/2020
#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

echo "sh_prechecking.log"
printf "Now the executing directory is %s\n" $PWD


#+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ extracting start and stop dates you choosed +++++++++++++++++++++++++++++++++++++++++++++++++++++++#
# "" means more stricter format checking for shell
[ ! -d "$ori_SARdir" ] && echo "$0: The original SAR data directory is inexistent! Please check it!" && exit 1
echo "+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" 
echo "Now extracting the start and stop dates from the original SAR data folder..."
# fork is used here, please note fork do not return the variables to the main shell, which is different with source
# here just the file (grep_S1_dates) is generated
chmod +x sh_grep_S1_dates.sh
# if $miss_type is not existent in $ori_SARdir, an error would be throwd and exit 
sh_grep_S1_dates $ori_SARdir $start_date $stop_date $miss_type
echo "+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" 
printf "sh_grep_S1_dates.sh is finished.\n"

#++++++++++++++++++++++++++++++++++++++++++++ creating data folder under $procdir and link the data form $ori_SARdir +++++++++++++++++++++++++++++++++++++++++++#
printf "\n"
echo "Now working with the data folder..."
mkdir -p $procdir/data

# checking the unzip_SAR_flag
if [ "$unzip_SAR_flag" == "Y" ] || [ "$unzip_SAR_flag" == "YES" ] || [ "$unzip_SAR_flag" == "y" ] || [ "$unzip_SAR_flag" == "yes" ]; then
	unzip_SAR_flag=0
	echo "Now unzipping the zip files in data folder..."
elif [ "$unzip_SAR_flag" == "N" ] || [ "$unzip_SAR_flag" == "NO" ] || [ "$unzip_SAR_flag" == "n" ] || [ "$unzip_SAR_flag" == "no" ]; then
	unzip_SAR_flag=1
else
	echo "$0: ERROR with the unzippping SAR data, pleaae check it in the config.table!!"
	exit 1
fi

[ -e "file_needed_s1a" ] && rm file_needed_s1a
[ -e "file_needed_s1b" ] && rm file_needed_s1b
miss_type=$(echo "$miss_type" | tr 'A-Z' 'a-z')
if [ "$miss_type" == "s1a" ]; then
	touch file_needed_s1a
	cat grep_dates_s1a >> file_needed_s1a
	file_needed_s1a=$(cat file_needed_s1a)
	rm file_needed_s1a
	#+++++++++ link the ZIP or unziped files to data folder ++++++++++#
	for file_needed_ele in $file_needed_s1a
	do
		ln -s $ori_SARdir/S1A_IW_SLC_*$file_needed_ele*  $procdir/data
		#[ "$unzip_SAR_flag" == "0"  ] && unzip $procdir/data/*$file_needed_ele* -d $procdir/data
		if [ "$unzip_SAR_flag" == "0"  ]; then
            unzip $procdir/data/S1A_IW_SLC_*$file_needed_ele*.zip -d $procdir/data
            rm $procdir/data/S1A_IW_SLC_*$file_needed_ele*.zip
        else
            cd $procdir/data
            [ -e S1A_IW_SLC_*$file_needed_ele*.zip ] && rm S1A_IW_SLC_*$file_needed_ele*.zip
            #ls S1A_IW_SLC_*$file_needed_ele*.zip
            #[ -e S1A_IW_SLC_*$file_needed_ele*.zip ] && echo "S1A_IW_SLC_*$file_needed_ele*.zip"
        fi
	done
elif [ "$miss_type" == "s1b" ]; then
	touch file_needed_s1b
	cat grep_dates_s1b >> file_needed_s1b
	file_needed_s1b=$(cat file_needed_s1b)
	rm file_needed_s1b
	#+++++++++ link the ZIP or unziped files to data folder ++++++++++#
	for file_needed_ele in $file_needed_s1b
	do
		ln -s $ori_SARdir/S1B_IW_SLC_*$file_needed_ele*  $procdir/data
		#[ "$unzip_SAR_flag" == "0"  ] && unzip $procdir/data/*$file_needed_ele* -d $procdir/data
		if [ "$unzip_SAR_flag" == "0"  ]; then
            unzip $procdir/data/S1B_IW_SLC_*$file_needed_ele*.zip -d $procdir/data
            rm $procdir/data/S1B_IW_SLC_*$file_needed_ele*.zip
        else
            cd $procdir/data
            [ -e S1B_IW_SLC_*$file_needed_ele*.zip ] && rm S1B_IW_SLC_*$file_needed_ele*.zip
        fi
	done
else
	touch file_needed_s1a file_needed_s1b
	cat grep_dates_s1a >> file_needed_s1a
	file_needed_s1a=$(cat file_needed_s1a)
	cat grep_dates_s1b >> file_needed_s1b
	file_needed_s1b=$(cat file_needed_s1b)
	rm file_needed_s1a file_needed_s1b
	#+++++++++ link the ZIP or unziped files to data folder ++++++++++#
	for file_needed_ele in $file_needed_s1a
	do
		ln -s $ori_SARdir/S1A_IW_SLC_*$file_needed_ele*  $procdir/data
		#[ "$unzip_SAR_flag" == "0"  ] && unzip $procdir/data/*$file_needed_ele* -d $procdir/data
		if [ "$unzip_SAR_flag" == "0"  ]; then
            unzip $procdir/data/S1A_IW_SLC_*$file_needed_ele*.zip -d $procdir/data
            rm $procdir/data/S1A_IW_SLC_*$file_needed_ele*.zip
        else
            cd $procdir/data
            [ -e S1A_IW_SLC_*$file_needed_ele*.zip ] && rm  S1A_IW_SLC_*$file_needed_ele*.zip
        fi
	done
	for file_needed_ele in $file_needed_s1b
	do
		ln -s $ori_SARdir/S1B_IW_SLC_*$file_needed_ele*  $procdir/data
		#[ "$unzip_SAR_flag" == "0"  ] && unzip $procdir/data/*$file_needed_ele* -d $procdir/data
		if [ "$unzip_SAR_flag" == "0"  ]; then
            unzip $procdir/data/S1B_IW_SLC_*$file_needed_ele*.zip -d $procdir/data
            rm $procdir/data/S1B_IW_SLC_*$file_needed_ele*.zip
        else
            cd $procdir/data
            [ -e S1A_IW_SLC_*$file_needed_ele*.zip ] && rm  S1A_IW_SLC_*$file_needed_ele*.zip
        fi
	done
fi

echo "Checking data folder is finished."

cd $procdir/S1_TS_proc

#++++++++++++++++++++++++++++++++++++++ checking the existence of opod folder and downloading orbit files if necessary ++++++++++++++++++++++++++++++++++++++++#
printf "\n"
echo "Now working with the opod folder..."
if [ "$opod_download_flag" == "Y" ] || [ "$opod_download_flag" == "YES" ] || [ "$opod_download_flag" == "y" ] || [ "$opod_download_flag" == "yes" ]; then
	mkdir -p $procdir/opod
	empty_flag=$(ls $procdir/opod | wc -w)
	if [ "$empty_flag" == "0" ]; then
		echo "Now downloading the opod orbit files..."
		cp ./sh_downloading_S1_opod.sh $procdir/opod
		[ -e grep_dates_s1a ] && cp ./grep_dates_s1a $procdir/opod
		[ -e grep_dates_s1b ] && cp ./grep_dates_s1b $procdir/opod
		cd $procdir/opod
		chmod +x sh_downloading_S1_opod.sh
		if [ "$miss_type" == "s1a" ]; then
			bash sh_downloading_S1_opod.sh $miss_type grep_dates_s1a
			rm grep_dates_s1a
		elif [ "$miss_type" == "s1b" ]; then
			bash sh_downloading_S1_opod.sh $miss_type grep_dates_s1b
			rm grep_dates_s1b
		elif [ "$miss_type" == "both" ]; then
			[ -e "grep_dates_s1" ] && rm grep_dates_s1
			cat grep_dates_s1a > grep_dates_s1
			cat grep_dates_s1b >> grep_dates_s1
			bash sh_downloading_S1_opod.sh $miss_type grep_dates_s1
			rm grep_dates_s1 grep_dates_s1a grep_dates_s1b
		else
			echo "$0: ERROR with mission type!! Please check it!!" && echo "" && exit 1
		fi
		rm sh_downloading_S1_opod.sh
		cd $procdir/S1_TS_proc
	else
		printf "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++\n"
		echo "$0: The opod folder is not empty, please check if the orbit files are already existed, or empty the folder!"
		exit 1
	fi
elif [ "$opod_download_flag" == "N" ] || [ "$opod_download_flag" == "NO" ] || [ "$opod_download_flag" == "n" ] || [ "$opod_download_flag" == "no" ]; then
	if [ -d $opoddir  ]; then
		empty_flag=$(ls $opoddir | wc -w)
		[ "$empty_flag" == "0"  ] && echo "$0: OPOD orbit files do not exsit, please check it in opod folder and choose downloading them in cofig.table!!" && exit 1
	fi
else
	echo "$0: ERROR with the opod downloading, pleaae check it in the config.table!!" && exit 1
fi
echo "Cheking opod folder is finished. "

#++++++++++++++++++++++++++++++++++++++++++++ checking the existence of dem folder and downloading DEM if necessary +++++++++++++++++++++++++++++++++++++++++++#
printf "\n"
echo "Now working with the dem folder..."
if [ "$dem_download_flag" == "Y" ] || [ "$dem_download_flag" == "YES" ] || [ "$dem_download_flag" == "y" ] || [ "$dem_download_flag" == "yes" ]; then
	mkdir -p $procdir/dem
	empty_flag=$(ls -A  $procdir/dem | wc -w)
	if [ "$empty_flag" == "0" ]; then
		echo "Now downloading the dem files..."
		cd $procdir/dem
		echo "sh_get_dem $max_lat $min_lat $max_lon $min_lon $dem_type $disdem_flag"
		sh_get_dem $max_lat $min_lat $max_lon $min_lon $dem_type $disdem_flag
		cd $procdir/S1_TS_proc
	else 
		printf "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++\n"
		echo "$0: The dem folder is not empty, please check if the dem files are already existed, or empty the folder!" && exit 1
		exit 1
	fi
elif [ "$dem_download_flag" == "N" ] || [ "$dem_download_flag" == "NO" ] || [ "$dem_download_flag" == "n" ] || [ "$dem_download_flag" == "no" ]; then
	if [ -d $demdir ]; then
		empty_flag=$(ls -A  $demdir |wc -w)
		if [ "$empty_flag" == "0" ]; then
			echo "$0: DEM files do not exsit, please check it in dem folder and choose downloading them in cofig.table!!" && exit 1
		fi
	else
		echo "$0: ERROR, the dem directory is not existed! Please check it!!" && exit 1
	fi
else
	echo "$0: ERROR with the DEM downloading, please check it in the config.table!!" && exit 1
fi

cd $procdir/S1_TS_proc
echo "Checking dem folder is finished."
echo "+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" 
date "+%Y-%m-%d %H:%M:%S"
printf "\n\n\n"
